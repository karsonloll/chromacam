Option Explicit
Dim shell, files, folder, pythonw, quote
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
folder = files.GetParentFolderName(WScript.ScriptFullName)
pythonw = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\ChromaCam\runtime\Scripts\pythonw.exe"
quote = Chr(34)
shell.CurrentDirectory = folder
If files.FileExists(pythonw) Then
    shell.Run quote & pythonw & quote & " " & quote & folder & "\chromacam.py" & quote, 1, False
Else
    shell.Run quote & folder & "\Start-ChromaCam.bat" & quote, 1, False
End If
