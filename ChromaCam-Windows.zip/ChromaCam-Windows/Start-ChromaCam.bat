@echo off
setlocal
cd /d "%~dp0"
set "CHROMACAM_ENV=%LOCALAPPDATA%\ChromaCam\runtime"
set "CHROMACAM_PY=%CHROMACAM_ENV%\Scripts\python.exe"

if exist "%CHROMACAM_PY%" goto :dependencies
call :find_python
if defined CHROMACAM_CREATE goto :create_env

where winget.exe >nul 2>&1
if errorlevel 1 goto :manual_install
echo Chroma Cam needs 64-bit Python 3.12 for its first run.
choice /c YN /n /m "Install Python 3.12 with Windows Package Manager now? [Y/N] "
if not "%errorlevel%"=="1" goto :manual_install
winget install --exact --id Python.Python.3.12 --source winget --scope user --architecture x64
if errorlevel 1 goto :manual_install
call :find_python
if not defined CHROMACAM_CREATE goto :manual_install

:create_env
%CHROMACAM_CREATE% -m venv "%CHROMACAM_ENV%"
if errorlevel 1 goto :failed

:dependencies
"%CHROMACAM_PY%" -c "import tkinter"
if errorlevel 1 goto :missing_tk
"%CHROMACAM_PY%" -c "import cv2, pyvirtualcam, cv2_enumerate_cameras" >nul 2>&1
if errorlevel 1 (
    "%CHROMACAM_PY%" -m pip install --only-binary=:all: -r requirements.txt
    if errorlevel 1 goto :failed
)
"%CHROMACAM_PY%" chromacam.py
if errorlevel 1 goto :failed
exit /b 0

:find_python
set "CHROMACAM_CREATE="
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" call :check_python "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if defined CHROMACAM_CREATE exit /b 0
if exist "%ProgramFiles%\Python312\python.exe" call :check_python "%ProgramFiles%\Python312\python.exe"
if defined CHROMACAM_CREATE exit /b 0
where py.exe >nul 2>&1
if not errorlevel 1 (
    py -3.12-64 -c "import tkinter, venv" >nul 2>&1
    if not errorlevel 1 set "CHROMACAM_CREATE=py -3.12-64"
)
if defined CHROMACAM_CREATE exit /b 0
for /f "delims=" %%P in ('where python.exe 2^>nul') do (
    if /i not "%%~dpP"=="%LOCALAPPDATA%\Microsoft\WindowsApps\" (
        if not defined CHROMACAM_CREATE call :check_python "%%P"
    )
)
exit /b 0

:check_python
"%~1" -c "import sys, struct, tkinter, venv; sys.exit(not (sys.version_info[:2] == (3, 12) and struct.calcsize('P') == 8))" >nul 2>&1
if not errorlevel 1 set CHROMACAM_CREATE="%~1"
exit /b 0

:manual_install
echo.
echo Install 64-bit Python 3.12 from https://www.python.org/downloads/windows/
echo Keep Tcl/Tk enabled, then close this window and launch Chroma Cam again.
pause
exit /b 1

:missing_tk
echo Enable Tcl/Tk through the Python 3.12 installer's Modify option, then try again.
pause
exit /b 1

:failed
echo Chroma Cam could not start. See the error above.
pause
exit /b 1
