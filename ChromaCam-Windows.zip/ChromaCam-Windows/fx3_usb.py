from collections import deque
import os
from pathlib import Path
import re
import shutil
import subprocess
from threading import Event, Thread
from time import monotonic

import cv2
import numpy as np

WSL = ["wsl.exe", "-d", "Ubuntu", "--exec"]
USB_HELP = "Attach the FX3 to WSL in PC Remote mode. See the Direct USB setup in README.txt."


def run_hidden(command, timeout=15):
    return subprocess.run(command, capture_output=True, timeout=timeout,
                          creationflags=subprocess.CREATE_NO_WINDOW)


def fx3_usb_rows(listing):
    for line in listing.splitlines():
        match = re.match(r"^\s*(\d+-\d+)\s+054c:0da3\s+.*?\s{2,}(Not shared|Shared(?: \(forced\))?|Attached)\s*$",
                         line, re.IGNORECASE)
        if match:
            yield match[1], match[2].lower()


def attach_fx3(stop):
    executable = shutil.which("usbipd.exe")
    if executable is None:
        installed = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "usbipd-win" / "usbipd.exe"
        if not installed.is_file():
            raise RuntimeError("usbipd-win was not found. See the Direct USB setup in README.txt.")
        executable = str(installed)
    result = run_hidden([executable, "list"])
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors="replace").strip() or "USB device listing failed.")
    cameras = list(fx3_usb_rows(result.stdout.decode(errors="replace")))
    if not cameras:
        raise RuntimeError("FX3 not found. Turn it on and select Remote Shooting / PC Remote, then click Start camera.")
    if len(cameras) != 1:
        raise RuntimeError("More than one Sony remote camera found. Connect only the FX3 or attach it manually.")
    bus, state = cameras[0]
    if state == "attached" or stop.is_set():
        return
    if state == "not shared":
        raise RuntimeError(f"Share the FX3 once from Administrator PowerShell: usbipd bind --busid {bus}")
    started = run_hidden([*WSL, "/bin/true"], timeout=25)
    if started.returncode:
        raise RuntimeError("Ubuntu could not start. Check the Direct USB setup in README.txt.")
    if stop.is_set():
        return
    attached = run_hidden([executable, "attach", "--wsl", "--busid", bus], timeout=25)
    if attached.returncode:
        raise RuntimeError(attached.stderr.decode(errors="replace").strip() or "Could not attach the FX3 to WSL.")


def jpeg_frames(stream):
    buffer = bytearray()
    while chunk := stream.read1(65536):
        buffer.extend(chunk)
        while True:
            start = buffer.find(b"\xff\xd8")
            if start < 0:
                del buffer[:-1]
                break
            del buffer[:start]
            end = buffer.find(b"\xff\xd9", 2)
            if end < 0:
                if len(buffer) > 16 * 1024 * 1024:
                    del buffer[:-1]
                break
            yield bytes(buffer[:end + 2])
            del buffer[:end + 2]


def fx3_port(listing):
    for line in listing.splitlines():
        words = line.split()
        if words and "ilme-fx3 " in line.casefold() and words[-1].startswith("usb:"):
            return words[-1]
    return None


class FX3UsbCapture:
    def __init__(self, stop):
        self.stop = stop
        self.latest = deque(maxlen=1)
        self.errors = deque(maxlen=6)
        self.eof = Event()
        self.process = None
        try:
            detected = run_hidden([*WSL, "gphoto2", "--auto-detect"])
            if fx3_port(detected.stdout.decode(errors="replace")) is None and not stop.is_set():
                attach_fx3(stop)
                if not stop.is_set():
                    detected = run_hidden([*WSL, "gphoto2", "--auto-detect"])
        except (OSError, subprocess.TimeoutExpired) as error:
            raise RuntimeError(USB_HELP) from error
        if stop.is_set():
            return
        port = fx3_port(detected.stdout.decode(errors="replace"))
        if detected.returncode or port is None:
            raise RuntimeError("FX3 not detected by gPhoto2. " + USB_HELP)
        self.process = subprocess.Popen(
            [*WSL, "gphoto2", "--port", port, "--quiet", "--capture-movie", "--stdout"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
        self.reader = Thread(target=self.receive_frames, daemon=True)
        self.diagnostics = Thread(target=self.receive_errors, daemon=True)
        self.reader.start()
        self.diagnostics.start()

    def receive_frames(self):
        with self.process.stdout as stream:
            try:
                for frame in jpeg_frames(stream):
                    if self.stop.is_set():
                        break
                    self.latest.append(frame)
            except OSError:
                pass
            finally:
                self.eof.set()

    def receive_errors(self):
        with self.process.stderr as stream:
            for line in stream:
                message = line.decode(errors="replace").strip()
                if message and message.strip("* "):
                    self.errors.append(message)

    def isOpened(self):
        return self.process is not None

    def read(self):
        deadline = monotonic() + 7
        while not self.stop.is_set():
            try:
                jpeg = self.latest.pop()
            except IndexError:
                if self.eof.is_set() or monotonic() >= deadline:
                    self.diagnostics.join(.2)
                    detail = self.errors[-1] if self.errors else "FX3 sent no live-view frames."
                    raise RuntimeError(detail + " " + USB_HELP)
                self.stop.wait(.01)
                continue
            image = cv2.imdecode(np.frombuffer(jpeg, dtype=np.uint8), cv2.IMREAD_COLOR)
            return image is not None, image
        return False, None

    def release(self):
        if self.process is None:
            return
        if self.process.poll() is None:
            self.process.terminate()
        self.process.wait(timeout=2)
        self.reader.join(.3)
        self.diagnostics.join(.3)
