from contextlib import nullcontext
import json
import os
from pathlib import Path
from queue import Empty, SimpleQueue
from threading import Event, Thread
from time import monotonic
import tkinter as tk
from tkinter import ttk

import cv2
import numpy as np
import pyvirtualcam
from cv2_enumerate_cameras import enumerate_cameras

from fx3_usb import FX3UsbCapture

SONY_INPUT = "Sony FX3 / Imaging Edge (auto)"
FX3_USB = "Sony FX3 (Direct USB via WSL)"
PREVIEW_ONLY = "Preview only"
PROFILES = {"576p / 24 fps": (1024, 576, 24), "480p / 15 fps": (640, 480, 15), "720p / 24 fps": (1280, 720, 24),
            "720p / 30 fps": (1280, 720, 30), "1080p / 30 fps": (1920, 1080, 30)}
SLIDERS = (("Saturation", 0, 200, 100), ("Brightness", -60, 60, 0),
           ("Contrast", 50, 150, 100), ("Warmth", -100, 100, 0),
           ("Tint", -100, 100, 0))
NEUTRAL = tuple(row[3] for row in SLIDERS)
SETTINGS = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "ChromaCam" / "settings.json"


def camera_sources():
    sources = {}
    for backend in (cv2.CAP_DSHOW, cv2.CAP_MSMF):
        try:
            cameras = enumerate_cameras(backend)
        except (OSError, RuntimeError):
            continue
        for camera in cameras:
            name = camera.name or f"Camera {camera.index}"
            if name in ("OBS Virtual Camera", "Unity Video Capture", "Unity Capture"):
                continue
            label = f"{name} [{camera.index}]" if backend == cv2.CAP_DSHOW else name
            if backend == cv2.CAP_MSMF and any(name == key.rsplit(" [", 1)[0] for key in sources):
                continue
            sources[label] = (camera.index, backend)
    return sources


def sony_source(sources):
    for term in ("imaging edge", "ilme-fx3", "fx3"):
        for label, source in sources.items():
            if term in label.casefold():
                return source
    return None


def color_matrix(values):
    if values == NEUTRAL:
        return None
    sat, brightness, contrast, warmth, tint = values
    sat /= 100
    contrast /= 100
    luma = np.array([0.114, 0.587, 0.299], dtype=np.float32)
    mix = contrast * (sat * np.eye(3, dtype=np.float32) + (1 - sat) * luma)
    offset = 128 * (1 - contrast) + brightness + np.array(
        [-warmth * .42, tint * .35, warmth * .42], dtype=np.float32)
    return np.column_stack((mix, offset))


def fit_frame(frame, width, height):
    h, w = frame.shape[:2]
    if (w, h) == (width, height):
        return frame
    crop_w = min(w, max(1, h * width // height))
    crop_h = min(h, max(1, w * height // width))
    x, y = (w - crop_w) // 2, (h - crop_h) // 2
    interpolation = cv2.INTER_AREA if crop_w > width else cv2.INTER_LINEAR
    return cv2.resize(frame[y:y + crop_h, x:x + crop_w], (width, height),
                      interpolation=interpolation)


class CameraWorker:
    def __init__(self, source, profile, backend, controls):
        self.source, self.profile, self.backend = source, profile, backend
        self.controls = controls
        self.messages = SimpleQueue()
        self.preview_frame = None
        self.stop = Event()
        self.thread = Thread(target=self.run, daemon=True)

    def run(self):
        capture = None
        try:
            width, height, fps = self.profile
            if self.source == FX3_USB:
                capture = FX3UsbCapture(self.stop)
            else:
                capture = cv2.VideoCapture(*self.source)
            if self.stop.is_set():
                return
            if not capture.isOpened():
                raise RuntimeError("Can't open this camera. Close other camera apps and refresh the input list.")
            if self.backend is None:
                sink = nullcontext()
            else:
                sink = pyvirtualcam.Camera(width=width, height=height, fps=fps,
                                           fmt=pyvirtualcam.PixelFormat.BGR,
                                           backend=self.backend)
            with sink as output:
                previous = None
                next_preview = 0.0
                last_frame = monotonic()
                frames = 0
                while not self.stop.is_set():
                    ok, image = capture.read()
                    now = monotonic()
                    if not ok:
                        if now - last_frame >= 2:
                            raise RuntimeError("No frames received. Check the camera cable and input number.")
                        self.stop.wait(.03)
                        continue
                    last_frame = now
                    values, preview, mirror = self.controls
                    if values != previous:
                        matrix = color_matrix(values)
                        previous = values
                    if output is not None:
                        image = fit_frame(image, width, height)
                    if matrix is not None:
                        image = cv2.transform(image, matrix)
                    if mirror:
                        image = cv2.flip(image, 1)
                    if output is not None:
                        output.send(image)
                    if frames == 0:
                        self.messages.put(f"Live to {output.device}" if output else "Live preview")
                    frames += 1
                    if (preview or output is None) and now >= next_preview:
                        preview_height = round(320 * image.shape[0] / image.shape[1])
                        small = cv2.resize(image, (320, preview_height), interpolation=cv2.INTER_AREA)
                        rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
                        self.preview_frame = f"P6\n320 {preview_height}\n255\n".encode() + rgb.tobytes()
                        next_preview = now + .125
                    if output is not None:
                        output.sleep_until_next_frame()
                    else:
                        self.stop.wait(max(0, next_preview - monotonic()))
        except Exception as error:
            if not self.stop.is_set():
                self.messages.put(str(error))
        finally:
            if capture is not None:
                capture.release()


class ChromaCam(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Chroma Cam")
        self.minsize(510, 420)
        self.worker = None
        self.closing = False
        self.last_preview = None
        self.preview_image = None
        self.settings_job = None
        self.configure(padx=18, pady=15)
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.build()
        self.after(60, self.poll)
        if self.auto_start.get() and self.input.get() == FX3_USB:
            self.after_idle(self.start)

    def build(self):
        style = ttk.Style(self)
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"))
        ttk.Label(self, text="Chroma Cam", style="Title.TLabel").pack(anchor="w")
        try:
            saved = json.loads(SETTINGS.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            saved = {}
        if not isinstance(saved, dict):
            saved = {}
        source = ttk.Frame(self, padding=(0, 10))
        source.pack(fill="x")
        ttk.Label(source, text="Camera input").grid(row=0, column=0, sticky="w")
        self.input = tk.StringVar(value=saved.get("input", FX3_USB))
        self.input_box = ttk.Combobox(source, state="readonly", textvariable=self.input, width=40)
        self.input_box.grid(row=1, column=0, columnspan=2, sticky="ew")
        source.columnconfigure(1, weight=1)
        self.refresh_button = ttk.Button(source, text="Refresh cameras", command=self.refresh_sources)
        self.refresh_button.grid(row=1, column=2, padx=(10, 0), sticky="e")
        ttk.Label(source, text="Output quality").grid(row=2, column=0, pady=(8, 0), sticky="w")
        self.profile = tk.StringVar(value=saved.get("profile", "576p / 24 fps"))
        self.quality = ttk.Combobox(source, values=list(PROFILES), state="readonly",
                                    textvariable=self.profile, width=16)
        self.quality.grid(row=3, column=0, sticky="w")
        ttk.Label(source, text="Output").grid(row=2, column=2, pady=(8, 0), sticky="w")
        self.backend = tk.StringVar(value=saved.get("backend", PREVIEW_ONLY))
        self.driver = ttk.Combobox(source, values=[PREVIEW_ONLY, "OBS Virtual Camera", "Unity Capture"],
                                    state="readonly", textvariable=self.backend, width=18)
        self.driver.grid(row=3, column=2, sticky="w")
        colors = ttk.Frame(self)
        colors.pack(fill="x")
        colors.columnconfigure(1, weight=1)
        self.values = []
        self.readouts = []
        for row, (name, low, high, default) in enumerate(SLIDERS):
            value = saved.get(name, default)
            value = min(high, max(low, value)) if type(value) is int else default
            setting = tk.DoubleVar(value=value)
            readout = ttk.Label(colors, width=5, anchor="e")
            self.values.append(setting)
            self.readouts.append(readout)
            ttk.Label(colors, text=name, width=12).grid(row=row, column=0, sticky="w")
            ttk.Scale(colors, from_=low, to=high, variable=setting).grid(row=row, column=1, sticky="ew", pady=5)
            readout.grid(row=row, column=2)
        options = ttk.Frame(self, padding=(0, 8))
        options.pack(fill="x")
        self.preview = tk.BooleanVar(value=False)
        self.mirror = tk.BooleanVar(value=saved.get("mirror") is True)
        ttk.Checkbutton(options, text="Preview", variable=self.preview).pack(side="left")
        ttk.Checkbutton(options, text="Mirror output", variable=self.mirror).pack(side="left", padx=10)
        ttk.Button(options, text="Reset colors", command=self.reset).pack(side="right")
        self.auto_start = tk.BooleanVar(value=saved.get("auto_start", True))
        ttk.Checkbutton(self, text="Start FX3 on launch", variable=self.auto_start).pack(anchor="w", pady=(0, 8))
        self.preview_label = ttk.Label(self, anchor="center")
        self.start_button = ttk.Button(self, text="Start camera", command=self.start)
        self.start_button.pack(fill="x")
        self.status = tk.StringVar(value="Camera off")
        self.status_label = ttk.Label(self, textvariable=self.status, wraplength=395, padding=(0, 9))
        self.status_label.pack(fill="x")
        for variable in [*self.values, self.preview, self.mirror, self.auto_start, self.input, self.profile, self.backend]:
            variable.trace_add("write", self.update_controls)
        self.refresh_sources()
        self.update_controls()

    def refresh_sources(self):
        self.sources = camera_sources()
        options = [FX3_USB, SONY_INPUT, *self.sources]
        self.input_box.configure(values=options)
        if self.input.get() not in options:
            self.input.set(FX3_USB)
        self.status.set("Ready. Select an input and start the camera.")

    def update_controls(self, *_):
        values = tuple(round(variable.get()) for variable in self.values)
        for label, value in zip(self.readouts, values):
            label.configure(text=str(value))
        if self.worker:
            self.worker.controls = values, self.preview.get(), self.mirror.get()
        if not self.preview.get():
            self.clear_preview()
        if self.settings_job is not None:
            self.after_cancel(self.settings_job)
        self.settings_job = self.after(450, self.save_settings)

    def save_settings(self):
        self.settings_job = None
        saved = {row[0]: round(variable.get()) for row, variable in zip(SLIDERS, self.values)}
        saved.update(input=self.input.get(), profile=self.profile.get(),
                     backend=self.backend.get(), mirror=self.mirror.get(), auto_start=self.auto_start.get())
        try:
            SETTINGS.parent.mkdir(parents=True, exist_ok=True)
            pending = SETTINGS.with_suffix(".tmp")
            pending.write_text(json.dumps(saved), encoding="utf-8")
            pending.replace(SETTINGS)
        except OSError:
            pass

    def reset(self):
        for variable, value in zip(self.values, NEUTRAL):
            variable.set(value)

    def start(self):
        if self.worker:
            return
        self.refresh_sources()
        label = self.input.get()
        if label == FX3_USB:
            source = FX3_USB
        elif label == SONY_INPUT:
            source = sony_source(self.sources)
        else:
            source = self.sources.get(label)
        if source is None:
            self.status.set("Selected video device is missing. Refresh cameras or choose Direct USB.")
            return
        backend = {PREVIEW_ONLY: None, "Unity Capture": "unitycapture"}.get(self.backend.get(), "obs")
        values = tuple(round(variable.get()) for variable in self.values)
        self.worker = CameraWorker(source, PROFILES.get(self.profile.get(), PROFILES["576p / 24 fps"]),
                                   backend, (values, self.preview.get(), self.mirror.get()))
        for widget in [self.input_box, self.quality, self.driver, self.refresh_button]:
            widget.configure(state="disabled")
        self.start_button.configure(text="Stop camera", command=self.stop_camera)
        self.status.set("Opening camera…")
        self.worker.thread.start()

    def stop_camera(self):
        if self.worker:
            self.worker.stop.set()
            self.start_button.configure(state="disabled")
            self.status.set("Stopping…")
            self.clear_preview()

    def clear_preview(self):
        self.preview_label.pack_forget()
        self.preview_label.configure(image="")
        self.preview_image = self.last_preview = None

    def poll(self):
        worker = self.worker
        if worker:
            finished = not worker.thread.is_alive()
            try:
                while True:
                    message = worker.messages.get_nowait()
                    if not worker.stop.is_set():
                        self.status.set(message)
            except Empty:
                pass
            if finished:
                self.worker = None
                self.clear_preview()
                self.start_button.configure(state="normal", text="Start camera", command=self.start)
                self.refresh_button.configure(state="normal")
                for widget in [self.input_box, self.quality, self.driver]:
                    widget.configure(state="readonly")
                if worker.stop.is_set():
                    self.status.set("Camera off")
            elif (self.preview.get() or worker.backend is None) and not worker.stop.is_set():
                preview = worker.preview_frame
                if preview is not None and preview is not self.last_preview:
                    self.preview_image = tk.PhotoImage(data=preview, format="PPM")
                    self.preview_label.configure(image=self.preview_image)
                    self.preview_label.pack(fill="x", before=self.start_button, pady=(0, 8))
                    self.last_preview = preview
        if self.closing and not self.worker:
            self.destroy()
        else:
            self.after(60, self.poll)

    def close(self):
        self.save_settings()
        self.closing = True
        self.stop_camera()
        if self.worker and self.worker.source != FX3_USB:
            self.after(2500, self.destroy)


if __name__ == "__main__":
    cv2.setNumThreads(1)
    ChromaCam().mainloop()
