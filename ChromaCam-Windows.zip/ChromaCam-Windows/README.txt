CHROMA CAM FOR WINDOWS
Watermark-free webcam color adjustments and virtual camera output.

SETUP (Windows 10/11, 64-bit)
1. Extract the whole ZIP.
2. For virtual camera output, if OBS Studio is installed, fully exit OBS. Chroma Cam can use
   the OBS Virtual Camera device with OBS closed.
   If you prefer a standalone virtual camera, download Unity Capture.
   Extract it to a permanent folder and run Install/Install.bat. Then
   choose Unity Capture in Chroma Cam.
   https://obsproject.com/download
   https://github.com/schellingb/UnityCapture
3. Double-click Start-ChromaCam.bat. If 64-bit Python 3.12 is missing,
   press Y when offered to install it. If Windows Package Manager is
   unavailable, install Python 3.12 manually with Tcl/Tk enabled.
   First launch installs dependencies from PyPI and needs internet.
   https://www.python.org/downloads/windows/
4. Follow the Direct USB section below for input setup.

EVERYDAY USE
After the one-time setup below, turn on the FX3 in PC Remote mode and
double-click Open-ChromaCam.vbs. This opens only Chroma Cam. The app
starts Ubuntu in the background, attaches your shared FX3 automatically,
and starts the feed using your saved output. You can minimize Chroma Cam
while the feed runs. Closing the app stops the feed.
Use Start-ChromaCam.bat if Python dependencies still need installation.

Start FX3 on launch can be toggled in Chroma Cam. To start the app when
you sign into Windows, keep this extracted folder in a permanent spot.
Press Win+R, enter shell:startup, and put a shortcut to Open-ChromaCam.vbs
in that folder. Have the FX3 on at sign-in or click Start camera afterward.

SONY FX3 DIRECT USB (NO IMAGING EDGE)
Chroma Cam uses gPhoto2 in Ubuntu on WSL 2 to read the FX3's PC Remote
live-view feed over the USB cable. It uses live-view frames rather than
the camera's 1080p/4K recording output. Selecting a larger output
resolution scales the feed. This source is experimental.

One-time setup:
1. Install and initialize Ubuntu on WSL 2. From an administrator
   PowerShell, run wsl --install -d Ubuntu if it isn't installed.
   Reboot if prompted, open Ubuntu, and create your Linux account.
   Run wsl --list --verbose in PowerShell and confirm Ubuntu is version 2.
   https://learn.microsoft.com/windows/wsl/install
2. In Ubuntu, run:
       sudo apt update
       sudo apt install gphoto2 usbutils
3. Install usbipd-win 5 or later. From PowerShell:
       winget install --exact --id dorssel.usbipd-win
   If needed, reopen PowerShell after installing. USB passthrough requires
   an up-to-date WSL kernel. See Microsoft's guide for Windows 10 details.
   https://learn.microsoft.com/windows/wsl/connect-usb

Connect and start:
1. On the FX3 choose Setup > USB > USB Connection Mode > Sel. When Connect.
   Plug in a USB data cable and select Remote Shoot (PC Remote) or Remote
   Shooting on the camera. If the camera appears as a drive, reconnect in
   PC Remote mode.
2. Keep an Ubuntu terminal open. In administrator PowerShell, run
       usbipd list
   Find the Sony device's BUSID. Replace <BUSID> with that ID:
       usbipd bind --busid <BUSID>
   The bind step is required once per device. Then, in PowerShell:
       usbipd attach --wsl --busid <BUSID>
   Repeat the attach step after reconnecting. Ubuntu can check the camera:
       gphoto2 --auto-detect
   The list should include ILME-FX3 (PC Control). If absent, check lsusb in
   Ubuntu and verify the camera is attached in PC Remote mode.
3. Start Chroma Cam, choose Sony FX3 (Direct USB via WSL) and Preview only,
   then click Start camera. Reset colors if the preview is dim or grayscale.
4. To use adjusted video in Discord, stop the preview and change Output
   to OBS Virtual Camera or Unity Capture. Start again and select that
   device in Discord. OBS Studio can stay closed.
5. To return the USB device to Windows, stop Chroma Cam and run
       usbipd detach --busid <BUSID>

OPTIONAL SONY IMAGING EDGE INPUT
1. Install Sony Imaging Edge Webcam. Sony's current download lists
   Windows 11. If you already have a working Imaging Edge Webcam device
   on Windows 10, Chroma Cam can attempt to use it.
   https://support.d-imaging.sony.co.jp/app/webcam/en/download/
2. Fully quit Imaging Edge Desktop (Remote). On the FX3, set
   Setup > USB > USB Connection Mode > Sel. When Connect. Connect a
   USB data cable and select Remote Shoot (PC Remote) or Remote Shooting.
   https://www.sony.com/electronics/support/articles/00247038
3. In Chroma Cam, choose Sony FX3 / Imaging Edge (auto), then Start camera.
   Chroma Cam finds the Sony video device by name. Seeing the device
   listed does not guarantee the camera body is streaming; use Preview
   only first to confirm you can see the actual picture. If you see a
   Sony placeholder, stop the feed and try Imaging Edge Webcam > USB
   Reset in the Windows Start menu, then power-cycle the camera.
4. For Discord or Zoom with Chroma Cam's color adjustments, stop the
   preview, set Output to OBS Virtual Camera or Unity Capture, and
   restart. Choose that output in the call app. Keep OBS Studio closed
   if using its virtual camera device. Choose a separate microphone.

ON WINDOWS 10 WITHOUT A WORKING SONY WEBCAM DEVICE
Connect the FX3's HDMI output to a USB HDMI capture card. In Chroma Cam,
click Refresh cameras and select the capture card by name. If camera
menus appear in the feed, disable HDMI Info. Display on the FX3.
https://www.sony.com/electronics/support/articles/00245829

CONTROLS AND PERFORMANCE
- Preview only requires no virtual camera output driver.
- For calls, try 576p / 24 fps to match Sony's USB feed size, or use
  480p / 15 fps for a lower processing load. Leave Preview off during
  calls to skip rendering a second copy of the feed.
- The live adjustments affect the output picture. Camera exposure,
  focus, and recording controls are adjusted on the FX3 itself.
